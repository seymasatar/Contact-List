
#Proje adı; Telefon Rehberi Uygulaması
#Bu projede bir telefon rehberi simülasyonu yapılmasını istiyoruz.

#1-Program açıldığında kullanıcıya, rehbere kişi ekleme, rehberden kişi silme, kişinin ismini
# ya da telefon bilgisini güncelleme ve rehberi listeleme seçeneklerini sununuz.
#2-Kullanıcıdan alacağınız girdilere göre, yukarıdaki işlemleri yapan bir program kodlayınız.
#3-Rehberi oluştururken sözlük veri tipini (dictionary) kullanınız.
#4-Yorum satırlari ile gerekli yerlerde kodlarınızi açıklamayı ihmal etmeyiniz.
#5-Kodunuzun okunaklı ve anlaşılabilir olmasına dikkat ediniz.


from typing import Dict

print('_______Contact List_______')

Name = ["hakan", "kerem", "ali", "bekir"]                             #Default isim listesi liste şeklinde oluşturulmuştur.
Tel = [31623232000, 31623232001, 31623232002, 31623232003]            #Default numara listesi liste şeklinde oluşturulmuştur.

k = 100

phn_dictionary = dict(zip(Name, Tel))                                 #Listeler dıctıonary halıne getırldı. (Keys ve values seklınde)
print(phn_dictionary)                                                 #Dıctıonary nın kontrolu yapılmıştır.

n = len(phn_dictionary)                                               #Dıctıonary nın uzunluk degerı 'n' e atanmısve update fonk. nunda kullanılmıstır.

def add(phn_dictionary):                                              #add defınasyonu olusturulmustur. Defınasyonun gorevı rehbere yenı user eklemektır.
    name1 = input("Please, enter the new name you want to add: ")
    num1 = int(input("Please, enter the number: "))
    if len(str(num1)) == 11:                                          #Userın 11 hanelı tel no gırmesı saglanmıstır.
        phn_dictionary[name1] = num1
        print(phn_dictionary)
    else:
        print('Please, enter correct input')



def delete(phn_dictionary):                                             #delete defınasyonu olusturulmustur. Defınasyonun gorevı rehberden ıstenılen userın sılınmesıdır.
    name2 = input("Please, enter the name you want to delete: ").lower()
    if name2 in phn_dictionary:
        del phn_dictionary[name2]
        print(phn_dictionary)
    else:
        print(name2, '____Sorry, Not Found!___')



def update(phn_dictionary, n, Name):                                    #update defınasyonu olusturulmustur. Defınasyonun gorevı rehberdeki user bılgısını guncellemektır.
    name3 = input("Please, enter the name which you want to update: ").lower()
    if name3 in phn_dictionary:
        for i in range(0, n):                                               #for dongusuyle tüm dıc. içinde update edılecek user ismi aranır.
            if Name[i] == name3:
                k = i
        if k != 100:                                                        #update defınasyonundaki for dongusunu 100 adetle sınırlamak ıçın 'k' tanımlanmıstır
            num3 = input("Please, enter the new number: ")                   #İsim bulundukta sonra yenı isim girilir.
            if len(str(num3)) == 11:
                phn_dictionary[name3] = num3
                print(phn_dictionary)                                        #Yeni isim dic.ye eklendıkten sonra update edilen dictionary yazdırılır.
            else:
                print('Please, enter correct input')
    else:
        print('Please, enter correct input')


def view(phn_dictionary):                                               #view defınasyonu olusturulmustur. Defınasyonun gorevı rehberdeki tüm user bilgisini göstermektir.
    print(phn_dictionary)

def exit(self):                                                         #exıt defınasyonu olusturulmustur. Defınasyonun gorevı işlemlerin bitirilmesinin ardindan cıkıs yapılmasını saglamaktır.
    print('(( Please, select no. 1 to 4 )) \n__________Thank you!__________')


while (True):                                                           #While döngüsüyle menu bılgısı yapılan ıslemın ardından tekrar cıktı ekranına getırılır.
    print("\n"
      "         1:Add a contact\n"
      "         2:Delete a contact\n"
      "         3:Update a contact\n"
      "         4:View contact list\n"
      "         5:Exit")
    choice = int(input("Please, enter your choice (1-4): "))


    if (choice == 1):                                                   #Userın menuden yapmak ıstedıgı ıslem ıcın ınput gırmesının ardından
        add(phn_dictionary)                                             #ilgili def. fonksıyonuna gıtmesını saglar.
    elif (choice == 2):
        delete(phn_dictionary)
    elif (choice == 3):
        update(phn_dictionary, n, Name)
    elif (choice == 4):
        view(phn_dictionary)
    else:
        exit(exit)

